// stdafx.h : The inclusion file of the standard system inclusion file��
// Or project-specific inclusion files that are frequently used but not often changed
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>



// TODO: Reference the other header files that the program needs here
