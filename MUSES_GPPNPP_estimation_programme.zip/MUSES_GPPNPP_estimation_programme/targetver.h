#pragma once

// Including SDKDDKVer.h will define the highest version of the Windows platform available.

// If you're building an application for a previous Windows platform, include WinSDKVer.h, and 
// set the WIN32_WINNT macro to the platforms you want to support, and then include SDKDDKVer.h.

#include <SDKDDKVer.h>
