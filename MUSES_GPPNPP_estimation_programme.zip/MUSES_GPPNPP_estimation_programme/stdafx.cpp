// stdafx.cpp : Only the source files of the standard include files are included
// NPP.pch will be used as a precompile header
// stdafx.obj will contain precompiled type information

#include "stdafx.h"

// TODO: IN STDAFX. H
// Reference any required additional header files instead of referencing them in this file
